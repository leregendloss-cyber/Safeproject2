plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.safexcode"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.safexcode"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-safe"
    }
}
