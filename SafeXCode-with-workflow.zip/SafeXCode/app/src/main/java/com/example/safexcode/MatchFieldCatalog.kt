package com.example.safexcode

/** Human-readable names for match fields. These are labels, not discovered game files. */
data class MatchField(
    val key: String,
    val label: String,
    val description: String,
    val sourceStatus: String = "Нет подтверждённого источника"
)

object MatchFieldCatalog {
    val fields = listOf(
        MatchField("match.players", "Игроки в матче", "Список участников текущего матча"),
        MatchField("team.count", "Игроков в команде", "Количество игроков по командам"),
        MatchField("match.round", "Текущий раунд", "Номер раунда и счёт"),
        MatchField("player.money", "Деньги игрока", "Игровая валюта участника"),
        MatchField("player.weapon", "Оружие игрока", "Текущее оружие / экипировка"),
        MatchField("player.pos", "Координаты игрока", "Позиция в игровом мире")
    )

    fun summaryLines(): String = fields.joinToString("\n") { "${it.key} — ${it.sourceStatus}" }
}
