package com.example.safexcode

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.net.TrafficStats
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var trafficText: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val updater = object : Runnable {
        override fun run() {
            trafficText?.text = trafficSummary()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 9, 12, 10)
            setBackgroundColor(0xEE172033.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Standoff 2 • список"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 8, 0)
        }
        val close = Button(this).apply {
            text = "×"
            isAllCaps = false
            setOnClickListener { stopSelf() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(close, LinearLayout.LayoutParams(44, 40))
        box.addView(header)

        val names = getSharedPreferences("safe_xcode", MODE_PRIVATE).getString("roster", "")
            ?.lineSequence()?.map { it.trim() }?.filter { it.isNotEmpty() }?.take(20)?.toList().orEmpty()
        val rosterText = buildString {
            append("Игроков в сохранённом списке: ${names.size}\n")
            append("Координаты игроков: недоступны\n")
            append("Список вводится вручную — это не данные матча.\n")
            if (names.isNotEmpty()) {
                append("\nСписок:\n")
                append(names.mapIndexed { i, name -> "${i + 1}. $name" }.joinToString("\n"))
            } else {
                append("Открой Safe XCode, чтобы добавить имена.")
            }
        }
        box.addView(TextView(this).apply {
            text = rosterText
            textSize = 12f
            setTextColor(0xFFE5EAF4.toInt())
            setPadding(0, 7, 0, 6)
        })
        box.addView(TextView(this).apply {
            text = "Поля матча\n" + MatchFieldCatalog.fields.joinToString("\n") { "${it.key}: —" }
            textSize = 11f
            setTextColor(0xFFD5DEEE.toInt())
            setPadding(0, 4, 0, 6)
        })
        trafficText = TextView(this).apply {
            text = trafficSummary()
            textSize = 11f
            setTextColor(0xFFE5EAF4.toInt())
            setPadding(0, 6, 0, 6)
        }
        box.addView(trafficText)
        box.addView(TextView(this).apply {
            text = "Общие счётчики устройства, не только игры. Только чтение."
            textSize = 10f
            setTextColor(0xFFB8C3D9.toInt())
        })
        box.addView(TextView(this).apply {
            text = "Перетащи за заголовок • × закрыть"
            textSize = 10f
            setTextColor(0xFFB8C3D9.toInt())
        })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 140 }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { windowManager.updateViewLayout(box, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        panel = box
        windowManager.addView(box, params)
        handler.post(updater)
    }

    private fun trafficSummary(): String {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) return "Сетевые счётчики недоступны"
        return "Трафик устройства\n↓ ${formatBytes(rx)}   ↑ ${formatBytes(tx)}"
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value Б"
        val units = arrayOf("КБ", "МБ", "ГБ", "ТБ")
        var amount = value.toDouble() / 1024.0
        var unit = 0
        while (amount >= 1024.0 && unit < units.lastIndex) { amount /= 1024.0; unit++ }
        return String.format(java.util.Locale.getDefault(), "%.1f %s", amount, units[unit])
    }

    override fun onDestroy() {
        handler.removeCallbacks(updater)
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
