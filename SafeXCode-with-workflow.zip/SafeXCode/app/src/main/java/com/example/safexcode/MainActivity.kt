package com.example.safexcode

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.TrafficStats
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var rosterEditor: EditText
    private var currentUri: Uri? = null
    private lateinit var trafficStatus: TextView
    private val trafficHandler = Handler(Looper.getMainLooper())
    private val trafficUpdater = object : Runnable {
        override fun run() {
            if (::trafficStatus.isInitialized) trafficStatus.text = trafficSummary()
            trafficHandler.postDelayed(this, 1000L)
        }
    }

    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { editor.setText(it.readText()) }
                currentUri = uri
                Toast.makeText(this, "Файл открыт", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось прочитать файл", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val saveAsFile = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) writeDocument(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("safe_xcode", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(0xFFF5F6F8.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Safe XCode • Standoff 2"
            textSize = 24f
            setTextColor(0xFF172033.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Безопасный помощник: ручной список участников для мини-панели и редактор выбранных текстовых файлов. Не читает память игры и не обходит защиту."
            textSize = 13f
            setTextColor(0xFF596273.toInt())
            setPadding(0, 8, 0, 12)
        })
        root.addView(TextView(this).apply {
            text = "Поля матча (понятные имена)"
            textSize = 16f
            setTextColor(0xFF172033.toInt())
            setPadding(0, 12, 0, 4)
        })
        root.addView(TextView(this).apply {
            text = MatchFieldCatalog.fields.joinToString("\n") { "${it.key}  ·  ${it.label}\n    ${it.sourceStatus}" }
            textSize = 12f
            setTextColor(0xFF344054.toInt())
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Это понятные имена полей, а не найденные файлы. Автоматические данные матча появятся только при наличии разрешённого источника."
            textSize = 12f
            setTextColor(0xFF596273.toInt())
            setPadding(0, 6, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Участники матча (вводи имена вручную, по одному на строку)"
            textSize = 15f
            setTextColor(0xFF172033.toInt())
        })
        rosterEditor = EditText(this).apply {
            hint = "Например:\nPlayer_1\nPlayer_2"
            setText(prefs.getString("roster", "") ?: "")
            gravity = Gravity.TOP or Gravity.START
            minLines = 3
            maxLines = 6
            textSize = 14f
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(rosterEditor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 6; bottomMargin = 6 })
        root.addView(makeButton("Сохранить список участников") {
            val names = rosterEditor.text.toString().lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.take(20).joinToString("\n")
            prefs.edit().putString("roster", names).apply()
            Toast.makeText(this, "Список сохранён для мини-панели", Toast.LENGTH_SHORT).show()
        })
        root.addView(makeButton("Показать мини-меню поверх игры") { enablePanel() })
        root.addView(TextView(this).apply {
            text = "Монитор сетевой активности (только чтение)"
            textSize = 16f
            setTextColor(0xFF172033.toInt())
            setPadding(0, 14, 0, 4)
        })
        trafficStatus = TextView(this).apply {
            text = trafficSummary()
            textSize = 13f
            setTextColor(0xFF344054.toInt())
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        root.addView(trafficStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 6 })
        root.addView(TextView(this).apply {
            text = "Показываются общие счётчики трафика устройства, а не содержимое пакетов и не только Standoff 2. Зашифрованные данные не расшифровываются."
            textSize = 12f
            setTextColor(0xFF596273.toInt())
            setPadding(0, 0, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Редактор выбранных файлов"
            textSize = 15f
            setTextColor(0xFF172033.toInt())
            setPadding(0, 12, 0, 4)
        })
        root.addView(makeButton("Открыть текстовый / JSON / XML файл") {
            openFile.launch(arrayOf("text/*", "application/json", "application/xml", "application/octet-stream"))
        })
        root.addView(makeButton("Сохранить изменения") {
            val uri = currentUri
            if (uri != null) writeDocument(uri) else saveAsFile.launch("game-config.txt")
        })
        editor = EditText(this).apply {
            hint = "Содержимое выбранного файла появится здесь…"
            gravity = Gravity.TOP or Gravity.START
            textSize = 13f
            setPadding(12, 12, 12, 12)
            minLines = 8
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(editor, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        trafficHandler.post(trafficUpdater)
    }

    override fun onDestroy() {
        trafficHandler.removeCallbacks(trafficUpdater)
        super.onDestroy()
    }

    private fun trafficSummary(): String {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        if (rx == TrafficStats.UNSUPPORTED.toLong() || tx == TrafficStats.UNSUPPORTED.toLong()) {
            return "Счётчики трафика недоступны на этом устройстве."
        }
        return "Получено: ${formatBytes(rx)}\nОтправлено: ${formatBytes(tx)}\n\nОбновление каждую секунду • режим только чтения"
    }

    private fun formatBytes(value: Long): String {
        if (value < 1024) return "$value Б"
        val units = arrayOf("КБ", "МБ", "ГБ", "ТБ")
        var amount = value.toDouble() / 1024.0
        var unit = 0
        while (amount >= 1024.0 && unit < units.lastIndex) {
            amount /= 1024.0
            unit++
        }
        return String.format(java.util.Locale.getDefault(), "%.2f %s", amount, units[unit])
    }

    private fun writeDocument(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(editor.text.toString()) }
            currentUri = uri
            Toast.makeText(this, "Изменения сохранены", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось сохранить файл. Выбери место, куда можно записывать.", Toast.LENGTH_LONG).show()
        }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 5 }
    }

    private fun enablePanel() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Разреши показ поверх других приложений, затем нажми кнопку ещё раз", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, FloatingPanelService::class.java))
        Toast.makeText(this, "Мини-меню запущено", Toast.LENGTH_SHORT).show()
    }
}
